/**
 * Driver class that runs Project 2
 * 
 * @author Seth Santos, Tiffany Chen
 * 
 */
public class RunProject2 {
    /**
     * Main driver to run Project2
     * @param args user input arguments
     */
    public static void main(String[] args) {
        new TransactionManager().run();
    }
}
